#include <GL/glut.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <cstdlib>

float angle = 0.0f;

// Lighting setup
void setupLighting() {
    GLfloat light_position[] = { 4.0, 4.0, 4.0, 1.0 };
    GLfloat light_ambient[] = { 0.3, 0.3, 0.3, 1.0 };
    GLfloat light_diffuse[] = { 0.8, 0.8, 0.8, 1.0 };
    GLfloat light_specular[] = { 1.0, 1.0, 1.0, 1.0 };

    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);

    glEnable(GL_LIGHT0);
    glEnable(GL_LIGHTING);
    glEnable(GL_COLOR_MATERIAL);
}

// Function to draw the broom handle (cylinder)
void drawHandle() {
    GLUquadric* quadric = gluNewQuadric();
    glColor3f(0.7f, 0.6f, 0.5f); // Light brownish handle
    glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
    gluCylinder(quadric, 0.07, 0.05, 2.0, 32, 32); // A long thin cylinder
}

// Function to draw the broom head (trapezoid-like structure)
void drawBroomHead() {
    glColor3f(0.6f, 0.4f, 0.2f); // Slightly redder color for the broom head

    glBegin(GL_QUADS);
    // Top face of the trapezoid (narrower)
    glVertex3f(-0.1f, 0.0f, 0.1f);
    glVertex3f(0.1f, 0.0f, 0.1f);
    glVertex3f(0.35f, -0.5f, 0.1f);
    glVertex3f(-0.35f, -0.5f, 0.1f);

    // Bottom face of the trapezoid (wider)
    glVertex3f(-0.10f, 0.0f, -0.1f);
    glVertex3f(0.10f, 0.0f, -0.1f);
    glVertex3f(0.35f, -0.5f, -0.1f);
    glVertex3f(-0.35f, -0.5f, -0.1f);

    // Connect the top and bottom faces
    glVertex3f(-0.1f, 0.0f, 0.1f);
    glVertex3f(-0.10f, 0.0f, -0.1f);
    glVertex3f(-0.35f, -0.5f, -0.1f);
    glVertex3f(-0.35f, -0.5f, 0.1f);

    glVertex3f(0.1f, 0.0f, 0.1f);
    glVertex3f(0.10f, 0.0f, -0.1f);
    glVertex3f(0.35f, -0.5f, -0.1f);
    glVertex3f(0.35f, -0.5f, 0.1f);
    glEnd();
}

// Function to draw broom bristles (fan-like structure)
void drawBristles() {
    glColor3f(0.1f, 0.1f, 0.1f); // Black bristles
    glLineWidth(2.0f); // Slightly thicker bristles for visibility

    glBegin(GL_LINES);
    // Draw bristles extending out from the broom head
    for (float i = -0.35f; i <= 0.35f; i += 0.01f) {
        // Randomize length slightly for more natural look
        float lengthVariation = ((rand() % 10) / 100.0f) - 0.05f;

        // Bristles front
        glVertex3f(i, -0.5f, 0.1f);
        glVertex3f(i * 1.8f, -1.5f + lengthVariation, 0.2f);

        // Bristles back
        glVertex3f(i, -0.5f, -0.1f);
        glVertex3f(i * 1.8f, -1.5f + lengthVariation, -0.2f);
    }

    // More bristles in the middle
    for (float i = -0.35f; i <= 0.35f; i += 0.015f) {
        float lengthVariation = ((rand() % 10) / 100.0f) - 0.05f;
        glVertex3f(i, -0.5f, 0.0f);
        glVertex3f(i * 1.6f, -1.4f + lengthVariation, 0.0f);
    }
    glEnd();
}

// Function to draw the complete broom
void drawBroom() {
    // Draw the handle
    glPushMatrix();
    glTranslatef(0.0f, 1.0f, 0.0f); // Move the handle up to ensure it points upwards
    drawHandle();
    glPopMatrix();

    // Draw the broom head
    glPushMatrix();
    glTranslatef(0.0f, 1.0f, 0.0f); // Position the broom head at the base of the handle
    drawBroomHead();
    glPopMatrix();

    // Draw the bristles
    glPushMatrix();
    glTranslatef(0.0f, 1.0f, 0.0f); // Place the bristles at the bottom of the head
    drawBristles();
    glPopMatrix();
}

// Render scene
void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    // Camera setup
    gluLookAt(4.0, 2.0, 6.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0);

    // Rotate the broom to visualize it from different angles
    glRotatef(angle, 0.0f, 1.0f, 0.0f);

    // Draw the broom
    drawBroom();

    glutSwapBuffers();
}

// Handle window resizing
void reshape(int width, int height) {
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (double)width / (double)height, 1.0, 200.0);
    glMatrixMode(GL_MODELVIEW);
}

// Update animation (rotate broom)
void update(int value) {
    angle += 1.0f; // Rotate the broom
    if (angle > 360) angle -= 360;
    glutPostRedisplay();
    glutTimerFunc(16, update, 0); // Call update again after 16 ms (~60 FPS)
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 800);
    glutCreateWindow("3D Broom OpenGL");

    glEnable(GL_DEPTH_TEST); // Enable depth testing for 3D rendering
    setupLighting();         // Set up lighting for more realistic rendering

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutTimerFunc(25, update, 0); // Set up animation callback

    glutMainLoop();
    return 0;
}


